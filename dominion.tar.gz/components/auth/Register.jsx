"use client";
import Link from 'next/link';
import Image from 'next/image';
import React, { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { signIn } from 'next-auth/react';
import bcrypt from 'bcryptjs';
import { Eye, EyeOff, X } from 'lucide-react'; // Import X icon for the close button

const Register = () => {
  const [email, setEmail] = useState("");
  const [username, setUsername] = useState("");
  const [actualPassword, setActualPassword] = useState("");
  const [actualConfirmPassword, setActualConfirmPassword] = useState("");
  const [error, setError] = useState(null);
  const [emptyFields, setEmptyFields] = useState([]);
  const [submitting, setSubmitting] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [showNotification, setShowNotification] = useState(null);
  const [acceptedTos, setAcceptedTos] = useState(false);

  const router = useRouter();

  useEffect(() => {
    if (error) {
      const timer = setTimeout(() => {
        setError(null);
      }, 3000);
      return () => clearTimeout(timer);
    }
  }, [error]);

  const showError = (message) => {
    setError(message);
  };


  const handlePasswordChange = (e) => {
    const newValue = e.target.value;
    setActualPassword(newValue);
  };

  const handleConfirmPasswordChange = (e) => {
    const newValue = e.target.value;
    setActualConfirmPassword(newValue);
  };

  const validateEmail = (email) => {
    const regex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
    return regex.test(email);
  };

  const validatePassword = (password) => {
    const regex = /^(?=.*[A-Z])(?=.*\d).{8,}$/;
    return regex.test(password);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setEmptyFields([]);
    let empty = [];

    if (email.length === 0) empty.push("email");
    if (username.length === 0) empty.push("username");
    if (actualPassword.length === 0) empty.push("password");
    if (actualConfirmPassword.length === 0) empty.push("confirmPassword");
    if (!acceptedTos) {
      setError("You must accept the Terms of Service and Privacy Policy");
      return;
    }


    setEmptyFields(empty);

    if (empty.length > 0) {
      setError("Please fill in all fields");
      return;
    }

    if (!validateEmail(email)) {
      setError("Invalid email address");
      setEmptyFields(["email"]);
      return;
    }

    if (!validatePassword(actualPassword)) {
      setError("Password must be 8+ chars, with 1 uppercase & 1 number");
      setEmptyFields(["password"]);
      return;
    }

    if (actualPassword !== actualConfirmPassword) {
      setError("Passwords do not match");
      setEmptyFields(["password", "confirmPassword"]);
      return;
    }

    setError(null);

    try {
      setSubmitting(true);
      const hashedPassword = await bcrypt.hash(actualPassword, 10);
      const response = await fetch("/api/auth/register", {
        method: 'POST',
        body: JSON.stringify({ email, username, password: hashedPassword }),
        headers: { "Content-Type": "application/json" },
      });

      if (response.ok) {
        setShowNotification(true); // Show notification on successful registration
      } else if (response.status === 406) {
        setError("OAUTH email, please sign in with Google");
        setEmail("");
      } else if (response.status === 409) {
        setError("Email already exists");
        setEmail("");
      } else {
        setError("Registration error");
      }
    } catch (error) {
      setError("Registration failed");
    } finally {
      setSubmitting(false);
    }
  };

  const togglePasswordVisibility = (type) => {
    if (type == "password") {
      setShowPassword(!showPassword);
    } else {
      setShowConfirmPassword(!showConfirmPassword);
    }
  };

  const handleCloseNotification = () => {
    setShowNotification(false); 
  };

  return (
    <div className="min-h-screen flex flex-col bg-gray-900 text-gray-300">
      <nav className="bg-gray-800 border-b border-gray-700 shadow-md">
        <div className="container mx-auto px-4 py-4">
          <div className="flex justify-between items-center">
            <div className="flex items-center">
              <h1 className="text-2xl font-bold text-blue-500 cursor-pointer">Dominion Login</h1>
            </div>
          </div>
        </div>
      </nav>

      <main className="container mx-auto px-4 py-8 flex-grow">
        <div className="bg-gray-800 rounded-lg p-6 border border-gray-700 shadow-lg max-w-[500px] mx-auto">
          <h2 className="text-2xl font-bold text-gray-100 mb-6">Create an Account</h2>
          <p className="text-gray-400 mb-6">Please fill in the details to register.</p>

          <form className="flex flex-col gap-4">
            <div>
              <label className="block text-gray-300 mb-2">Email</label>
              <input
                type="email"
                placeholder="Enter your email"
                className="w-full bg-gray-700 border border-gray-600 rounded px-3 py-2 text-gray-200 focus:outline-none focus:ring-2 focus:ring-blue-600"
              />
            </div>

            <div>
              <label className="block text-gray-300 mb-2">Username</label>
              <input
                type="text"
                placeholder="Enter your username"
                className="w-full bg-gray-700 border border-gray-600 rounded px-3 py-2 text-gray-200 focus:outline-none focus:ring-2 focus:ring-blue-600"
              />
            </div>

            <div>
              <label className="block text-gray-300 mb-2">Password</label>
              <div className="relative">
                <input
                  type="password"
                  placeholder="Enter your password"
                  className="w-full bg-gray-700 border border-gray-600 rounded px-3 py-2 text-gray-200 focus:outline-none focus:ring-2 focus:ring-blue-600 pr-10"
                />

                <button
                  type="button"
                  className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-300"
                >
                  <Eye size={18} />
                </button>
              </div>
            </div>

            <div>
              <label className="block text-gray-300 mb-2">Confirm Password</label>
              <div className="relative">
                <input
                  type="password"
                  placeholder="Confirm your password"
                  className="w-full bg-gray-700 border border-gray-600 rounded px-3 py-2 text-gray-200 focus:outline-none focus:ring-2 focus:ring-blue-600 pr-10"
                />
                <button
                  type="button"
                  className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-300"
                >
                  <Eye size={18} />
                </button>
              </div>
            </div>

            <button
              type="submit"
              className="bg-blue-700 hover:bg-blue-800 text-white px-4 py-2 rounded-lg flex items-center justify-center"
            >
              Register
            </button>
          </form>

          <div className="text-center mt-4 text-gray-400">
            Already have an account?{" "}
            <a href="/auth/login" className="text-blue-400 hover:underline">
              Login
            </a>
          </div>
        </div>
      </main>

      <footer className="bg-gray-800 border-t border-gray-700 py-4">
        <div className="container mx-auto px-4">
          <div className="text-center text-gray-400 text-sm">
            Dominion Login &copy; {new Date().getFullYear()}
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Register;
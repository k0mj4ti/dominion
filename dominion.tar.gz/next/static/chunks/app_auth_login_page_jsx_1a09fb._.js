(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_auth_login_page_jsx_1a09fb._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_auth_login_page_jsx_1a09fb._.js",
  "chunks": [
    "static/chunks/node_modules_ff28b8._.js",
    "static/chunks/_6523b8._.js"
  ],
  "source": "dynamic"
});

(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_page_072828.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_page_072828.js",
  "chunks": [
    "static/chunks/node_modules_next_dist_ea69ac._.js",
    "static/chunks/app_page_a68060.js"
  ],
  "source": "dynamic"
});

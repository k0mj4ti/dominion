(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push(["static/chunks/app_page_jsx_bd719d._.js", {

"[project]/app/page.jsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, k: __turbopack_refresh__, m: module, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "default": (()=>Home)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/image.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_refresh__.signature();
"use client";
;
;
function Home() {
    _s();
    const [dragX, setDragX] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(0);
    const [isDragging, setIsDragging] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [startX, setStartX] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(0);
    const [cardState, setCardState] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("center");
    const [cardCount, setCardCount] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(1);
    const cardRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const containerRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const animationRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const lastMouseXRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(0);
    const [cardData, setCardData] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [daySurvived, setDaySurvived] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(1);
    const DRAG_THRESHOLD = 100;
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "Home.useEffect": ()=>{
            fetch("/api/cards").then({
                "Home.useEffect": (res)=>res.json()
            }["Home.useEffect"]).then({
                "Home.useEffect": (data)=>{
                    if (data.length > 0) {
                        const randomCard = data[Math.floor(Math.random() * data.length)];
                        setCardData(randomCard);
                        console.log(randomCard);
                    } else {
                        console.error("No cards available from API");
                    }
                }
            }["Home.useEffect"]).catch({
                "Home.useEffect": (error)=>console.error("Failed to fetch cards:", error)
            }["Home.useEffect"]);
        }
    }["Home.useEffect"], [
        daySurvived
    ]);
    const resetCard = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "Home.useCallback[resetCard]": ()=>{
            setDragX(0);
            setCardState("center");
            setCardCount({
                "Home.useCallback[resetCard]": (prev)=>prev + 1
            }["Home.useCallback[resetCard]"]);
        }
    }["Home.useCallback[resetCard]"], []);
    const processSwipe = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "Home.useCallback[processSwipe]": (direction)=>{
            console.log(`Card was swiped ${direction}`);
            setTimeout(resetCard, 300);
        }
    }["Home.useCallback[processSwipe]"], [
        resetCard
    ]);
    const handleDragStart = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "Home.useCallback[handleDragStart]": (e)=>{
            if (cardState !== "center") return;
            const clientX = e.type.includes('touch') ? e.touches[0].clientX : e.clientX;
            setIsDragging(true);
            setStartX(clientX - dragX);
            lastMouseXRef.current = clientX;
            if (animationRef.current) cancelAnimationFrame(animationRef.current);
            if (e.type.includes('touch')) e.preventDefault();
        }
    }["Home.useCallback[handleDragStart]"], [
        dragX,
        cardState
    ]);
    const animateDrag = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "Home.useCallback[animateDrag]": (clientX)=>{
            const targetX = clientX - startX;
            const resistance = 0.8 - Math.min(0.6, Math.abs(targetX) / 1000);
            setDragX(targetX * resistance);
            lastMouseXRef.current = clientX;
        }
    }["Home.useCallback[animateDrag]"], [
        startX
    ]);
    const handleDragMove = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "Home.useCallback[handleDragMove]": (e)=>{
            if (!isDragging || cardState !== "center") return;
            const clientX = e.type.includes('touch') ? e.touches[0].clientX : e.clientX;
            if (animationRef.current) cancelAnimationFrame(animationRef.current);
            animationRef.current = requestAnimationFrame({
                "Home.useCallback[handleDragMove]": ()=>animateDrag(clientX)
            }["Home.useCallback[handleDragMove]"]);
            e.preventDefault();
        }
    }["Home.useCallback[handleDragMove]"], [
        isDragging,
        cardState,
        animateDrag
    ]);
    const handleDragEnd = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "Home.useCallback[handleDragEnd]": ()=>{
            if (!isDragging || cardState !== "center") return;
            setIsDragging(false);
            const velocity = lastMouseXRef.current - startX;
            const momentumThreshold = DRAG_THRESHOLD * 0.6;
            if (Math.abs(dragX) > DRAG_THRESHOLD || Math.abs(velocity) > momentumThreshold) {
                const targetSide = dragX > 0 || velocity > momentumThreshold ? "leaving-right" : "leaving-left";
                setCardState(targetSide);
                setDaySurvived({
                    "Home.useCallback[handleDragEnd]": (prev)=>prev + 1
                }["Home.useCallback[handleDragEnd]"]);
                processSwipe(targetSide === "leaving-right" ? "right" : "left");
            } else {
                const animateToCenter = {
                    "Home.useCallback[handleDragEnd].animateToCenter": ()=>{
                        setDragX({
                            "Home.useCallback[handleDragEnd].animateToCenter": (current)=>{
                                const next = current * 0.85;
                                if (Math.abs(next) < 0.5) {
                                    cancelAnimationFrame(animationRef.current);
                                    return 0;
                                }
                                animationRef.current = requestAnimationFrame(animateToCenter);
                                return next;
                            }
                        }["Home.useCallback[handleDragEnd].animateToCenter"]);
                    }
                }["Home.useCallback[handleDragEnd].animateToCenter"];
                animationRef.current = requestAnimationFrame(animateToCenter);
            }
        }
    }["Home.useCallback[handleDragEnd]"], [
        isDragging,
        dragX,
        cardState,
        processSwipe,
        startX,
        DRAG_THRESHOLD
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "Home.useEffect": ()=>{
            if (isDragging) {
                window.addEventListener('mousemove', handleDragMove, {
                    passive: false
                });
                window.addEventListener('touchmove', handleDragMove, {
                    passive: false
                });
                window.addEventListener('mouseup', handleDragEnd);
                window.addEventListener('touchend', handleDragEnd);
            }
            return ({
                "Home.useEffect": ()=>{
                    window.removeEventListener('mousemove', handleDragMove);
                    window.removeEventListener('touchmove', handleDragMove);
                    window.removeEventListener('mouseup', handleDragEnd);
                    window.removeEventListener('touchend', handleDragEnd);
                    if (animationRef.current) cancelAnimationFrame(animationRef.current);
                }
            })["Home.useEffect"];
        }
    }["Home.useEffect"], [
        isDragging,
        handleDragMove,
        handleDragEnd
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "Home.useEffect": ()=>{
            return ({
                "Home.useEffect": ()=>{
                    if (animationRef.current) cancelAnimationFrame(animationRef.current);
                }
            })["Home.useEffect"];
        }
    }["Home.useEffect"], []);
    const rotation = Math.sign(dragX) * Math.min(Math.abs(dragX) * 0.04, 10);
    const getCardTransform = ()=>{
        if (cardState === "leaving-right") return `translate(${window.innerWidth}px, 0) rotate(${rotation}deg)`;
        if (cardState === "leaving-left") return `translate(-${window.innerWidth}px, 0) rotate(${rotation}deg)`;
        return `translate(${dragX}px, 0) rotate(${rotation}deg)`;
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "grid grid-rows-4 h-screen",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "bg-red-400 text-center p-4 text-xl font-bold",
                children: "Statok"
            }, void 0, false, {
                fileName: "[project]/app/page.jsx",
                lineNumber: 134,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                ref: containerRef,
                className: "bg-green-400 row-span-3 relative overflow-hidden",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "absolute inset-0 flex justify-center items-center",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        ref: cardRef,
                        className: "bg-blue-400 h-[70vh] w-[50vh] rounded-lg shadow-lg cursor-move select-none will-change-transform",
                        style: {
                            transform: getCardTransform(),
                            touchAction: "none",
                            transformOrigin: "center center",
                            opacity: cardState === "center" ? 1 : 0.8,
                            transition: !isDragging ? "transform 0.3s cubic-bezier(0.25, 0.46, 0.45, 0.94)" : "none"
                        },
                        onMouseDown: handleDragStart,
                        onTouchStart: handleDragStart,
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "text-white text-center p-4",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "text-xl font-bold mb-2",
                                    children: cardData?.title
                                }, void 0, false, {
                                    fileName: "[project]/app/page.jsx",
                                    lineNumber: 151,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    children: cardData?.description
                                }, void 0, false, {
                                    fileName: "[project]/app/page.jsx",
                                    lineNumber: 152,
                                    columnNumber: 15
                                }, this),
                                cardData?.choices?.length >= 2 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "relative w-full flex justify-between px-4",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "absolute left-0 transition-all duration-300 text-left",
                                            style: {
                                                opacity: dragX < -20 ? 1 : 0,
                                                transform: `translateX(${dragX < -20 ? 0 : -20}px)`
                                            },
                                            children: [
                                                "👈 ",
                                                cardData.choices[0].text
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/app/page.jsx",
                                            lineNumber: 155,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "absolute right-0 transition-all duration-300 text-right",
                                            style: {
                                                opacity: dragX > 20 ? 1 : 0,
                                                transform: `translateX(${dragX > 20 ? 0 : 20}px)`
                                            },
                                            children: [
                                                cardData.choices[1].text,
                                                " 👉"
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/app/page.jsx",
                                            lineNumber: 165,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/page.jsx",
                                    lineNumber: 154,
                                    columnNumber: 15
                                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "text-white"
                                }, void 0, false, {
                                    fileName: "[project]/app/page.jsx",
                                    lineNumber: 176,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/page.jsx",
                            lineNumber: 150,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/app/page.jsx",
                        lineNumber: 137,
                        columnNumber: 11
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/app/page.jsx",
                    lineNumber: 136,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/app/page.jsx",
                lineNumber: 135,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/page.jsx",
        lineNumber: 133,
        columnNumber: 5
    }, this);
}
_s(Home, "d2a7fd71kc+ddOP6h4z3QyuNCt4=");
_c = Home;
var _c;
__turbopack_refresh__.register(_c, "Home");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_refresh__.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/app/page.jsx [app-rsc] (ecmascript, Next.js server component, client modules)": ((__turbopack_context__) => {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, t: __turbopack_require_real__ } = __turbopack_context__;
{
}}),
}]);

//# sourceMappingURL=app_page_jsx_bd719d._.js.map
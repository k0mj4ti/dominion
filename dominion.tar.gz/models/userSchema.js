import mongoose, { Schema, model, models } from "mongoose"

const userSchema = new Schema({
    username: {
        type: String,
        required: true
    },
    password: {
        type: String,
        required: true
    },
    currentStats: {
        type: [Number],
        required: true,
        default: [50, 50, 50, 50]
    },
    daysSurvived: {
        type: Number,
        required: true,
        default: 0
    }
}, {timestamps: true})

const User = models.User || model("User", userSchema)
export default User;